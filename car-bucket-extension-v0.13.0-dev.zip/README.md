# Car Bucket v0.13.0-dev

Universal extraction development build. Not a release yet.

## Extraction strategy
1. Schema.org / JSON-LD
2. Semantic/labeled DOM
3. data-* and price-related attributes
4. VIN-anchored listing blocks
5. Page application state exposed by common frameworks
6. Embedded JSON/state scripts
7. Same-origin loaded resource data
8. Conservative whole-page fallback

The extractor scores competing values and records field-level evidence. Payment amounts, MSRP, rebates, fees, and other incidental numbers are penalized rather than treated as vehicle price.

A MAIN-world page-state collector reads only JSON-serializable application state already exposed by the page. It does not bypass authentication or access controls.
