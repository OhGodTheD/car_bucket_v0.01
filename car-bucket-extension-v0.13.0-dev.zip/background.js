const WATCH_ALARM = 'car-bucket-watch';

chrome.runtime.onInstalled.addListener(async () => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  chrome.alarms.create(WATCH_ALARM, { periodInMinutes: 360 });
});

chrome.runtime.onStartup?.addListener(() => {
  chrome.alarms.create(WATCH_ALARM, { periodInMinutes: 360 });
});

chrome.commands?.onCommand?.addListener((command) => {
  if (command === 'open-bucket') {
    chrome.windows.getCurrent().then(w => chrome.sidePanel.open({ windowId: w.id })).catch(() => {});
  }
});

async function getListings() {
  const { listings = [] } = await chrome.storage.local.get({ listings: [] });
  return listings;
}

async function checkWatchedListings() {
  const listings = await getListings();
  const watched = listings.filter(x => x.watch && x.url);
  if (!watched.length) return;

  const updates = new Map();
  for (const item of watched.slice(0, 12)) {
    let tabId;
    try {
      const tab = await chrome.tabs.create({ url: item.url, active: false });
      tabId = tab.id;
      await new Promise((resolve) => {
        let done = false;
        const finish = () => { if (!done) { done = true; chrome.tabs.onUpdated.removeListener(listener); resolve(); } };
        const listener = (id, info) => {
          if (id === tabId && info.status === 'complete') setTimeout(finish, 1800);
        };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(finish, 10000);
      });
      const response = await chrome.tabs.sendMessage(tabId, { type: 'EXTRACT_LISTING' }).catch(() => null);
      if (response?.ok && response.listing) updates.set(item.id, response.listing);
    } catch (_) {
      // A single site failure should not stop the rest of the watch run.
    } finally {
      if (tabId) chrome.tabs.remove(tabId).catch(() => {});
    }
  }

  if (!updates.size) return;
  const now = new Date().toISOString();
  let changed = false;
  const next = listings.map(old => {
    const fresh = updates.get(old.id);
    if (!fresh) return old;
    const priceChanged = old.price != null && fresh.price != null && old.price !== fresh.price;
    const availabilityChanged = old.url && fresh.title && /no longer available|sold|not found|removed/i.test(fresh.title);
    if (priceChanged || availabilityChanged) changed = true;
    const history = Array.isArray(old.priceHistory) ? [...old.priceHistory] : [];
    if (fresh.price != null && (history.length === 0 || history[history.length - 1].price !== fresh.price)) {
      history.push({ price: fresh.price, at: now });
    }
    return { ...old, ...fresh, id: old.id, savedAt: old.savedAt, lastCheckedAt: now, priceHistory: history, priceChangedAt: priceChanged ? now : old.priceChangedAt, availabilityChangedAt: availabilityChanged ? now : old.availabilityChangedAt };
  });
  await chrome.storage.local.set({ listings: next, lastWatchRun: now });

  if (changed && chrome.notifications) {
    const changedItems = next.filter(x => updates.has(x.id) && (x.priceChangedAt === now || x.availabilityChangedAt === now));
    const message = changedItems.slice(0, 3).map(x => `${x.title || 'Vehicle'}${x.price != null ? ` — $${Number(x.price).toLocaleString()}` : ''}`).join('\n');
    chrome.notifications.create(`cb-${Date.now()}`, { type: 'basic', iconUrl: 'icon128.png', title: 'Car Bucket update', message: message || 'A watched vehicle changed.' });
  }
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === WATCH_ALARM) checkWatchedListings();
});
