(() => {
  let pageState = {};
  window.addEventListener('message', e => {
    if (e.source === window && e.data?.type === 'CAR_BUCKET_PAGE_STATE') pageState = e.data.payload || {};
  });
  const requestPageState = () => window.dispatchEvent(new CustomEvent('CAR_BUCKET_REQUEST_STATE'));
  const merge = (a,b) => {
    const out={...a};
    for(const k of ['title','year','make','model','trim','mileage','price','vin','stock','dealer','location','image']) {
      if((out[k]===null||out[k]===undefined||out[k]==='') && b?.[k]!==null && b?.[k]!==undefined && b?.[k]!=='') out[k]=b[k];
    }
    out.extractionConfidence={...(a?.extractionConfidence||{}),...(b?.extractionConfidence||{})};
    out.extractionEvidence={...(a?.extractionEvidence||{}),...(b?.extractionEvidence||{})};
    out.extractionDebug=b?.extractionDebug||a?.extractionDebug;
    return out;
  };
  async function extract() {
    requestPageState();
    await new Promise(r=>setTimeout(r,80));
    window.CarBucketExtractor?.setPageState?.(pageState);
    if(!window.CarBucketExtractor?.extractUniversal) throw new Error('Car Bucket extractor unavailable');
    let result=await window.CarBucketExtractor.extractUniversal();
    // Dynamic inventory sites often populate the listing after document_idle.
    if(!result.vin || result.price==null || !result.model || result.mileage==null) {
      await new Promise(r=>setTimeout(r,1200));
      result=merge(result,await window.CarBucketExtractor.extractUniversal());
    }
    if(!result.vin || result.price==null) {
      await new Promise(r=>setTimeout(r,2200));
      result=merge(result,await window.CarBucketExtractor.extractUniversal());
    }
    return result;
  }
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if(message?.type==='EXTRACT_LISTING') {
      extract().then(listing=>sendResponse({ok:true,listing})).catch(e=>sendResponse({ok:false,error:String(e)}));
      return true;
    }
    if(message?.type==='CB_DIAGNOSTICS') {
      const universal=window.CarBucketExtractor?.detectPlatform?.()||{name:'unknown',confidence:0};
      sendResponse({ok:true,host:location.hostname.replace(/^www\./,''),adapter:'universal',platform:universal.name,title:document.title,hasLdJson:!!document.querySelector('script[type="application/ld+json"]'),bodyLength:document.body?.innerText?.length||0});
      return true;
    }
  });
})();
