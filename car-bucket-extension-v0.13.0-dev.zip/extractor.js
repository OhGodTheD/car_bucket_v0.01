(() => {
  // Car Bucket Universal Vehicle Extraction Engine v0.11
  // Strategy: structured data -> semantic DOM -> labeled text -> embedded state -> same-origin data resources.
  // The engine is intentionally conservative: when a value is ambiguous, it leaves it blank rather than guessing.
  const CB = window.CarBucketExtractor = {};
  let pageState = {};
  CB.setPageState = v => { pageState = v || {}; };

  const clean = v => typeof v === 'string' ? v.replace(/\s+/g, ' ').trim() : (v ?? '');
  const bodyText = () => document.body?.innerText || '';
  const lines = () => bodyText().split(/\r?\n/).map(clean).filter(Boolean);
  const meta = name => clean(document.querySelector(`meta[name="${name}"],meta[property="${name}"]`)?.content || '');
  const text = el => clean(el?.textContent || '');
  const attr = (el, names) => {
    if (!el) return '';
    for (const name of names) {
      const v = clean(el.getAttribute?.(name));
      if (v) return v;
    }
    return '';
  };
  const yearFrom = s => Number(String(s || '').match(/\b(19\d{2}|20\d{2})\b/)?.[1]) || null;
  const vinFrom = s => String(s || '').match(/\b[A-HJ-NPR-Z0-9]{17}\b/i)?.[0]?.toUpperCase() || '';
  const milesFrom = s => {
    const m = String(s || '').replace(/,/g, '').match(/\b(\d{1,7})\s*(?:miles|mi\.?|kilometers|km)\b/i);
    return m ? Number(m[1]) : null;
  };
  const stockFrom = s => String(s || '').match(/(?:stock\s*(?:#|number|no\.?)?|stk\s*#|unit\s*(?:#|number)?)\s*[:#-]?\s*([A-Z0-9][A-Z0-9_-]{2,})/i)?.[1] || '';
  const moneyCandidates = s => {
    const out = [];
    const raw = String(s || '').replace(/\u00a0/g, ' ');
    const re = /(?:US\$|\$)\s*([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{3,7})(?:\.\d{2})?/g;
    let m;
    while ((m = re.exec(raw))) {
      const value = Number(m[1].replace(/,/g, ''));
      if (Number.isFinite(value) && value >= 1000 && value <= 1000000) out.push({value, index:m.index, raw:m[0]});
    }
    return out;
  };
  const money = s => moneyCandidates(s)[0]?.value ?? null;
  const PRICE_LABEL_RE = /(?:your\s+price|our\s+price|sale\s+price|selling\s+price|internet\s+price|online\s+price|advertised\s+price|asking\s+price|dealer\s+price|cash\s+price|purchase\s+price|e[- ]?price|special\s+price|vehicle\s+price|current\s+price|retail\s+price|price)\b/i;
  const PRICE_NUMBER_RE = /(?:US\$|\$)\s*([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{3,7})(?:\.\d{2})?|\b([0-9]{1,3}(?:,[0-9]{3})+|[0-9]{4,7})(?:\.\d{2})?\b/g;

  function priceNumbersFromLabelledText(s) {
    const raw = String(s || '').replace(/\u00a0/g,' ');
    if (!PRICE_LABEL_RE.test(raw)) return [];
    const out=[];
    for (const m of raw.matchAll(PRICE_NUMBER_RE)) {
      const n=Number((m[1]||m[2]||'').replace(/,/g,''));
      if (Number.isFinite(n) && n>=1000 && n<=1000000) out.push(n);
    }
    return out;
  }

  function allDataAttributes() {
    const out=[];
    for (const el of document.querySelectorAll('*')) {
      for (const a of [...(el.attributes||[])]) {
        const n=a.name.toLowerCase();
        if (/price|vin|stock|mileage|odometer|msrp|vehicle|inventory/.test(n)) {
          out.push({name:a.name,value:a.value,el});
        }
      }
      if (out.length>3000) break;
    }
    return out;
  }

  function embeddedJsonCandidates(vinValue) {
    const out=[];
    const vinUpper=String(vinValue||'').toUpperCase();
    const scripts=[...document.scripts].filter(s=>s.textContent && s.textContent.length<5000000);
    for(const node of scripts){
      const raw=node.textContent;
      if(vinUpper && !raw.toUpperCase().includes(vinUpper)) continue;
      let parsed=null;
      try { parsed=JSON.parse(raw); } catch(_){ continue; }
      const walk=(v,path='root')=>{
        if(!v || typeof v!=='object') return;
        if(Array.isArray(v)){ for(let i=0;i<Math.min(v.length,500);i++) walk(v[i],`${path}[${i}]`); return; }
        const flat=JSON.stringify(v);
        if(vinUpper && flat.toUpperCase().includes(vinUpper)){
          const priceKeys=/price|sellingPrice|salePrice|internetPrice|retailPrice|cashPrice|askingPrice|offerPrice/i;
          for(const [k,val] of Object.entries(v)){
            if(priceKeys.test(k)){
              const nums=typeof val==='number'?[val]:moneyCandidates(String(val)).map(x=>x.value);
              for(const n of nums) if(n>=1000) out.push({value:n,score:88,evidence:`embedded JSON ${path}.${k}`,context:flat.slice(0,1800)});
            }
          }
        }
        for(const [k,x] of Object.entries(v)) if(x && typeof x==='object') walk(x,`${path}.${k}`);
      };
      walk(parsed);
    }
    return out;
  }

  function ldObjects() {
    const out = [];
    const seen = new Set();
    const walk = v => {
      if (!v || typeof v !== 'object' || seen.has(v)) return;
      seen.add(v);
      if (Array.isArray(v)) return v.forEach(walk);
      out.push(v);
      Object.values(v).forEach(x => { if (x && typeof x === 'object') walk(x); });
    };
    document.querySelectorAll('script[type="application/ld+json"]').forEach(node => {
      try { walk(JSON.parse(node.textContent)); } catch (_) {}
    });
    return out;
  }

  const typeOf = obj => {
    const t = obj?.['@type'];
    return Array.isArray(t) ? t.join(' ').toLowerCase() : String(t || '').toLowerCase();
  };
  const objName = v => typeof v === 'string' ? clean(v) : clean(v?.name || v?.value || v?.url || '');
  const firstObj = v => Array.isArray(v) ? (v.find(Boolean) || {}) : (v && typeof v === 'object' ? v : {});
  const isVehicleLike = o => /vehicle|car|product|automotive|motorvehicle|auto/.test(typeOf(o)) || !!(o?.vehicleIdentificationNumber || o?.mileageFromOdometer);

  function structured() {
    const objects = ldObjects();
    const candidates = objects.filter(isVehicleLike);
    // Prefer the object carrying the VIN, then the one carrying mileage/offers.
    // Many dealer sites split identity and Offer data across several JSON-LD nodes.
    const vehicle = candidates.find(o => o.vehicleIdentificationNumber || o.vin) ||
                    candidates.find(o => o.mileageFromOdometer && o.offers) ||
                    candidates.find(o => o.offers) || candidates[0] || {};
    const related = candidates.filter(o => o !== vehicle);
    const offerObjects = [];
    const pushOffers = v => {
      if (Array.isArray(v)) v.forEach(x => { if (x && typeof x === 'object') offerObjects.push(x); });
      else if (v && typeof v === 'object') offerObjects.push(v);
    };
    pushOffers(vehicle.offers);
    for (const o of related) pushOffers(o.offers);
    const offers = offerObjects.find(o => Number.isFinite(Number(o.price)) || o.priceSpecification) || firstObj(offerObjects);
    const priceSpec = firstObj(offers.priceSpecification || vehicle.priceSpecification);
    const seller = firstObj(offers.seller || vehicle.seller || related.find(o=>o.seller)?.seller);
    const address = firstObj(seller.address || vehicle.address || related.find(o=>o.address)?.address);
    const image = Array.isArray(vehicle.image) ? vehicle.image[0] : objName(vehicle.image);
    const price = Number(offers.price ?? priceSpec.price);
    const mileage = Number(firstObj(vehicle.mileageFromOdometer).value);
    const vin = clean(vehicle.vehicleIdentificationNumber || vehicle.vin) || vinFrom(JSON.stringify(vehicle));
    const stock = clean(vehicle.stockNumber || vehicle.stock || vehicle.sku || '') || stockFrom(JSON.stringify(vehicle));
    return {
      vehicle, offers, seller, address,
      title: clean(vehicle.name || vehicle.headline || ''),
      year: Number(vehicle.modelDate || vehicle.vehicleModelDate) || yearFrom(vehicle.name),
      make: objName(vehicle.brand) || objName(vehicle.manufacturer),
      model: clean(vehicle.model || ''),
      trim: clean(vehicle.vehicleConfiguration || vehicle.trim || vehicle.vehicleConfigurationName || ''),
      price: Number.isFinite(price) && price >= 1000 ? price : null,
      mileage: Number.isFinite(mileage) && mileage >= 0 ? mileage : null,
      vin, stock,
      dealer: objName(seller),
      location: [clean(address.streetAddress), clean(address.addressLocality), clean(address.addressRegion), clean(address.postalCode)].filter(Boolean).join(', '),
      image: image || meta('og:image')
    };
  }

  function valueAfterLabel(labelNames, sourceLines = lines()) {
    const labels = labelNames.map(x => x.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    const exact = new RegExp(`^(?:${labels.join('|')})\\s*[:#-]?\\s*(.*)$`, 'i');
    const only = new RegExp(`^(?:${labels.join('|')})\\s*[:#-]?\\s*$`, 'i');
    for (let i=0; i<sourceLines.length; i++) {
      const m = sourceLines[i].match(exact);
      if (m?.[1]) return m[1].trim();
      if (only.test(sourceLines[i])) return sourceLines[i+1] || '';
    }
    return '';
  }

  const STRONG_PRICE_LABELS = [
    'your price','our price','sale price','selling price','internet price','online price',
    'advertised price','asking price','dealer price','cash price','purchase price',
    'e-price','special price','online special','internet special','vehicle price',
    'today\'s price','todays price','market price','current price','retail price'
  ];
  const NEGATIVE_PRICE_TERMS = [
    'payment','per month','monthly','/month','mo.','lease','finance','financing','down payment',
    'due at signing','due today','tax','taxes','fee','fees','doc fee','documentation','rebate',
    'rebates','discount','discounts','msrp','sticker price','market adjustment','dealer addendum',
    'accessories','warranty','protection','trade allowance','trade-in','trade value','total after tax'
  ];

  function scorePriceCandidate(value, context, source, explicitLabel='') {
    const c = String(context || '').toLowerCase();
    let score = source === 'structured' ? 95 : source === 'label' ? 90 : source === 'dom' ? 70 : source === 'data' ? 65 : 45;
    if (STRONG_PRICE_LABELS.some(x => c.includes(x))) score += 30;
    if (explicitLabel && STRONG_PRICE_LABELS.some(x => c.includes(x))) score += 15;
    if (NEGATIVE_PRICE_TERMS.some(x => c.includes(x))) score -= 45;
    if (/\b(?:monthly|payment|lease|finance|down)\b/i.test(c)) score -= 40;
    if (/\b(?:mi|miles|distance)\b/i.test(c)) score -= 15;
    if (/\b(?:rebate|discount|msrp|sticker|fee|tax)\b/i.test(c)) score -= 35;
    if (value < 2500) score -= 5; // old/cheap vehicles are valid, just slightly more ambiguous.
    if (value > 150000) score -= 10;
    return score;
  }

  function nearbyContext(el, radius=2) {
    if (!el) return '';
    const parent = el.parentElement;
    const chunks = [text(el), text(parent), text(parent?.parentElement)];
    if (parent) {
      const siblings = [...parent.children].slice(0, 8).map(text).filter(Boolean);
      chunks.push(...siblings);
    }
    return clean(chunks.join(' ')).slice(0, 1800);
  }

  function domPriceCandidates() {
    const candidates = [];
    const selectors = [
      '[itemprop="price"]','[itemprop="lowPrice"]','[data-price]','[data-msrp]',
      '[data-testid*="price" i]','[aria-label*="price" i]','[class*="sale-price" i]',
      '[class*="selling-price" i]','[class*="internet-price" i]','[class*="vehicle-price" i]',
      '[class*="asking-price" i]','[class*="our-price" i]','[class*="your-price" i]',
      '[class*="online-price" i]','[class*="cash-price" i]','[class*="price" i]'
    ];
    const seen = new Set();
    for (const selector of selectors) {
      let nodes=[];
      try { nodes=[...document.querySelectorAll(selector)]; } catch (_) {}
      for (const el of nodes.slice(0,80)) {
        const raw = attr(el,['content','data-price','value']) || text(el);
        for (const c of moneyCandidates(raw)) {
          const ctx = nearbyContext(el);
          const key = `${c.value}|${ctx.slice(0,100)}`;
          if (seen.has(key)) continue;
          seen.add(key);
          candidates.push({value:c.value, score:scorePriceCandidate(c.value,ctx,'dom'), evidence:`DOM ${selector}`, context:ctx});
        }
      }
    }
    return candidates;
  }

  function labeledPriceCandidates(sourceLines=lines()) {
    const candidates=[];
    for (let i=0; i<sourceLines.length; i++) {
      const line = sourceLines[i];
      const lower=line.toLowerCase();
      const strong = STRONG_PRICE_LABELS.find(x => lower.includes(x));
      if (!strong) continue;
      for (const j of [i-2,i-1,i,i+1,i+2,i+3]) {
        if (j<0 || j>=sourceLines.length) continue;
        for (const c of moneyCandidates(sourceLines[j])) {
          const ctx=sourceLines.slice(Math.max(0,i-2),Math.min(sourceLines.length,i+4)).join(' ');
          candidates.push({value:c.value,score:scorePriceCandidate(c.value,ctx,'label',strong),evidence:`label: ${strong}`,context:ctx});
        }
        for (const n of priceNumbersFromLabelledText(sourceLines[j])) {
          const ctx=sourceLines.slice(Math.max(0,i-2),Math.min(sourceLines.length,i+4)).join(' ');
          candidates.push({value:n,score:scorePriceCandidate(n,ctx,'label',strong)-4,evidence:`numeric label: ${strong}`,context:ctx});
        }
      }
    }
    return candidates;
  }

  function titleParts(title) {
    const m=String(title||'').match(/\b(19\d{2}|20\d{2})\s+([A-Za-z][A-Za-z0-9&.'-]*)\s+(.+)/);
    if (!m) return {year:yearFrom(title),make:'',model:'',trim:''};
    const tail=m[3].replace(/\s+(?:for sale|in stock|new|used)\b.*$/i,'').trim();
    const words=tail.split(/\s+/);
    return {year:Number(m[1]),make:m[2],model:words.shift()||'',trim:words.join(' ')};
  }

  function findLabeledField(labels, sourceLines=lines()) {
    return valueAfterLabel(labels, sourceLines);
  }

  function extractFromVehicleAnchor(vinValue) {
    if (!vinValue) return {};
    const walker=document.createTreeWalker(document.body||document.documentElement,NodeFilter.SHOW_TEXT);
    let node;
    while ((node=walker.nextNode())) {
      if (!String(node.nodeValue||'').toUpperCase().includes(vinValue.toUpperCase())) continue;
      let el=node.parentElement;
      for (let depth=0; el && depth<6; depth++,el=el.parentElement) {
        const ctx=text(el);
        if (ctx.length<30 || ctx.length>12000) continue;
        const ls=ctx.split(/\r?\n/).map(clean).filter(Boolean);
        const price=labeledPriceCandidates(ls).sort((a,b)=>b.score-a.score)[0];
        const mileage=milesFrom(findLabeledField(['Mileage','Miles','Odometer','Odometer Reading'],ls));
        const stock=findLabeledField(['Stock','Stock Number','Stock #','Unit Number','Inventory #'],ls)||stockFrom(ctx);
        if (price || mileage || stock) return {price:price?.value||null,mileage,stock,priceEvidence:price?.evidence||'',priceScore:price?.score||0};
      }
    }
    return {};
  }

  function extractEmbeddedState(vinValue) {
    const out=[];
    const scripts=[...document.scripts].filter(s=>!s.src && s.textContent && s.textContent.length<2000000).slice(0,120);
    for (const s of scripts) {
      const raw=s.textContent;
      if (vinValue && !raw.toUpperCase().includes(vinValue.toUpperCase())) continue;
      const idx=vinValue ? raw.toUpperCase().indexOf(vinValue.toUpperCase()) : -1;
      const ctx=idx>=0 ? raw.slice(Math.max(0,idx-5000),Math.min(raw.length,idx+7000)) : raw.slice(0,12000);
      const prices=moneyCandidates(ctx).map(c=>({value:c.value,score:scorePriceCandidate(c.value,ctx,'data'),evidence:'embedded page state',context:ctx}));
      for(const p of prices) out.push(p);
    }
    return out.concat(embeddedJsonCandidates(vinValue));
  }

  async function extractSameOriginResources(vinValue) {
    if (!vinValue || !window.performance?.getEntriesByType) return [];
    const entries=performance.getEntriesByType('resource')
      .map(e=>e.name).filter(Boolean)
      .filter(u=>{ try { const x=new URL(u,location.href); return x.origin===location.origin && !/\.(?:jpg|jpeg|png|webp|gif|svg|css|woff2?|ttf|ico)(?:\?|$)/i.test(x.pathname); } catch (_) { return false; } })
      .filter((u,i,a)=>a.indexOf(u)===i)
      .slice(-20);
    const results=[];
    for(const url of entries){
      try{
        const res=await fetch(url,{credentials:'same-origin',cache:'no-store'});
        const type=res.headers.get('content-type')||'';
        if(!type.includes('json') && !type.includes('javascript') && !type.includes('text')) continue;
        const raw=(await res.text()).slice(0,1000000);
        if(!raw.toUpperCase().includes(vinValue.toUpperCase())) continue;
        const idx=raw.toUpperCase().indexOf(vinValue.toUpperCase());
        const ctx=raw.slice(Math.max(0,idx-5000),Math.min(raw.length,idx+7000));
        for(const c of moneyCandidates(ctx)) results.push({value:c.value,score:scorePriceCandidate(c.value,ctx,'data')+10,evidence:'same-origin inventory data',context:ctx,url});
      }catch(_){ }
    }
    try {
      const frames=await sameOriginFrames();
      for(const raw of frames){
        if(vinValue && !raw.toUpperCase().includes(vinValue.toUpperCase())) continue;
        const idx=raw.toUpperCase().indexOf(vinValue.toUpperCase());
        const ctx=raw.slice(Math.max(0,idx-6000),Math.min(raw.length,idx+8000));
        for(const c of moneyCandidates(ctx)) results.push({value:c.value,score:scorePriceCandidate(c.value,ctx,'data')+8,evidence:'same-origin iframe data',context:ctx});
        for(const n of priceNumbersFromLabelledText(ctx)) results.push({value:n,score:76,evidence:'same-origin iframe labelled price',context:ctx});
      }
    }catch(_){}
    return results;
  }

  function detectPlatform() {
    const hay=[
      [...document.scripts].map(s=>s.src).join(' '),
      [...document.querySelectorAll('meta')].map(m=>m.content||'').join(' '),
      document.documentElement?.outerHTML?.slice(0,600000)||''
    ].join(' ').toLowerCase();
    const signatures=[
      ['dealeron',['dealeron']],['dealerinspire',['dealerinspire']],['dealerfire',['dealerfire']],
      ['vinsolutions',['vinsolutions']],['dealertrack',['dealertrack']],['cdk',['cdkglobal','cdk dealer']],
      ['carsforsale',['carsforsale.com']],['roadster',['roadster.com']],['dealer.com',['dealer.com']],
      ['dealer-eprocess',['dealer eprocess','dealereprocess']],['autotrader',['autotrader.com']],
      ['cars.com',['cars.com']],['cargurus',['cargurus.com']]
    ];
    for(const [name,needles] of signatures) if(needles.some(n=>hay.includes(n))) return {name,confidence:70};
    return {name:'unknown',confidence:0};
  }

  function dataAttributeCandidates(vinValue) {
    const out=[];
    const vinUpper=String(vinValue||'').toUpperCase();
    for(const item of allDataAttributes()){
      const raw=String(item.value||'');
      const n=item.name.toLowerCase();
      if(vinUpper && raw.toUpperCase()===vinUpper) continue;
      const ctx=nearbyContext(item.el);
      if(/price|msrp|selling|sale|internet|cash/.test(n)){
        const nums=moneyCandidates(raw).map(x=>x.value);
        for(const value of nums) out.push({value,score:scorePriceCandidate(value,`${n} ${ctx}`,'data')+18,evidence:`attribute ${item.name}`,context:ctx});
      }
    }
    return out;
  }

  async function sameOriginFrames() {
    const docs=[];
    for(const frame of document.querySelectorAll('iframe')){
      try{
        const src=frame.getAttribute('src')||'';
        if(!src) continue;
        const u=new URL(src,location.href);
        if(u.origin!==location.origin) continue;
        const r=await fetch(u.href,{credentials:'same-origin',cache:'no-store'});
        if(r.ok) docs.push(await r.text());
      }catch(_){ }
    }
    return docs;
  }

  function pageStateCandidates(vinValue) {
    const out=[];
    const vinUpper=String(vinValue||'').toUpperCase();
    const raws=Object.values(pageState||{}).filter(Boolean);
    for (const raw of raws) {
      const str=String(raw);
      if (vinUpper && !str.toUpperCase().includes(vinUpper)) continue;
      const upper=str.toUpperCase();
      const pos=vinUpper ? upper.indexOf(vinUpper) : -1;
      const ctx=pos>=0 ? str.slice(Math.max(0,pos-8000),Math.min(str.length,pos+10000)) : str.slice(0,20000);
      // Key-aware extraction gets priority over every generic number in state.
      const keyRe=/(?:"|')?([A-Za-z][A-Za-z0-9_ -]{0,45}(?:price|sellingPrice|salePrice|internetPrice|onlinePrice|cashPrice|askingPrice|advertisedPrice|vehiclePrice|retailPrice|ePrice))["']?\s*:\s*(?:"\$?([0-9,]+(?:\.\d+)?)"|([0-9,]+(?:\.\d+)?))/gi;
      let m;
      while((m=keyRe.exec(ctx))){
        const n=Number((m[2]||m[3]||'').replace(/,/g,''));
        if(Number.isFinite(n) && n>=1000 && n<=1000000) out.push({value:n,score:scorePriceCandidate(n,ctx,'data')+25,evidence:'page application state price key',context:ctx.slice(0,1800)});
      }
      for(const c of moneyCandidates(ctx)) out.push({value:c.value,score:scorePriceCandidate(c.value,ctx,'data')+5,evidence:'page application state',context:ctx.slice(0,1800)});
    }
    return out;
  }

  function chooseBest(candidates) {
    return [...candidates].filter(x=>x && Number.isFinite(x.value)).sort((a,b)=>b.score-a.score)[0] || null;
  }

  async function extractUniversal() {
    const s=structured();
    const ls=lines();
    const h1=text(document.querySelector('h1'));
    const pageTitle=clean(document.title);
    const title=s.title || h1 || pageTitle;
    const parts=titleParts(title || pageTitle);

    const vinValue=s.vin || findLabeledField(['VIN','VIN Number','Vehicle Identification Number'],ls) || vinFrom(bodyText());
    const anchor=extractFromVehicleAnchor(vinValue);

    const priceCandidates=[];
    if(s.price!=null) priceCandidates.push({value:s.price,score:95,evidence:'Schema.org Offer.price',context:'structured offer'});
    priceCandidates.push(...labeledPriceCandidates(ls));
    priceCandidates.push(...domPriceCandidates());
    priceCandidates.push(...dataAttributeCandidates(vinValue));
    priceCandidates.push(...pageStateCandidates(vinValue));
    if(anchor.price!=null) priceCandidates.push({value:anchor.price,score:anchor.priceScore,evidence:anchor.priceEvidence,context:'VIN-nearby listing block'});
    priceCandidates.push(...extractEmbeddedState(vinValue));

    // A whole-page money scan is last resort only. It is heavily penalized so incidental
    // payments, MSRP, rebates, and fees do not beat a real listing price.
    const whole=bodyText();
    for(const c of moneyCandidates(whole).slice(0,80)){
      const ctx=whole.slice(Math.max(0,c.index-140),Math.min(whole.length,c.index+180));
      priceCandidates.push({value:c.value,score:scorePriceCandidate(c.value,ctx,'fallback'),evidence:'page text fallback',context:ctx});
    }
    const bestPrice=chooseBest(priceCandidates);

    const mileage=s.mileage ?? milesFrom(findLabeledField(['Mileage','Miles','Odometer','Odometer Reading'],ls)) ?? milesFrom(text(document.querySelector('[itemprop="mileageFromOdometer"]'))) ?? null;
    const stock=s.stock || findLabeledField(['Stock','Stock Number','Stock #','Stock No.','Unit Number','Inventory #','Inventory Number'],ls) || anchor.stock || stockFrom(bodyText());
    const make=s.make || findLabeledField(['Make','Manufacturer'],ls) || parts.make;
    const model=s.model || findLabeledField(['Model','Model Name'],ls) || parts.model;
    const trim=s.trim || findLabeledField(['Trim','Vehicle Configuration','Grade','Series'],ls) || parts.trim;
    const year=s.year || yearFrom(title) || yearFrom(pageTitle);
    const dealer=s.dealer || findLabeledField(['Dealer','Dealer Name','Seller'],ls) || text(document.querySelector('address'));
    const location=s.location || findLabeledField(['Location','Dealer Location','Address','Dealer Address'],ls) || text(document.querySelector('address'));
    const image=s.image || meta('og:image') || attr(document.querySelector('img'),['src','data-src','data-lazy-src']);
    const platform=detectPlatform();

    let resourcePrice=null;
    // Same-origin resource inspection is only attempted when the normal DOM ladder did not
    // produce a reasonably strong price. This keeps pages fast while catching JS inventory APIs.
    if((!bestPrice || bestPrice.score<65) && vinValue) {
      const resourceCandidates=await extractSameOriginResources(vinValue);
      resourcePrice=chooseBest(resourceCandidates);
    }
    const finalPrice=resourcePrice && (!bestPrice || resourcePrice.score>bestPrice.score) ? resourcePrice : bestPrice;

    const confidence={
      vin:vinValue ? (s.vin?0.99:0.94):0,
      price:finalPrice ? Math.min(0.99,Math.max(0.35,finalPrice.score/110)):0,
      mileage:mileage!=null ? (s.mileage!=null?0.97:0.86):0,
      identity:(year&&make&&model)?(s.make&&s.model?0.97:0.82):0,
      stock:stock? (s.stock?0.97:0.82):0,
      dealer:dealer? (s.dealer?0.95:0.72):0
    };

    return {
      id:crypto.randomUUID(), savedAt:new Date().toISOString(),
      source:location.hostname.replace(/^www\./,''), url:location.href,
      title:[year,make,model,trim].filter(Boolean).join(' ') || title || 'Vehicle',
      year:year||null, make:clean(make), model:clean(model), trim:clean(trim),
      mileage, price:finalPrice?.value ?? null, vin:clean(vinValue), stock:clean(stock),
      dealer:clean(dealer), location:clean(location), image:clean(image),
      notes:'', status:'Saved', adapter:'universal', platform:platform.name,
      confidence:Math.round(Math.max(...Object.values(confidence))*100),
      extractionConfidence:confidence,
      extractionEvidence:{
        price:finalPrice?.evidence||'not found',
        vin:s.vin?'Schema.org vehicleIdentificationNumber':(vinValue?'VIN label/pattern':'not found'),
        mileage:s.mileage?'Schema.org mileageFromOdometer':(mileage!=null?'labeled/semantic mileage':'not found'),
        identity:s.make&&s.model?'Schema.org vehicle':(year&&make&&model?'title/labels':'partial')
      },
      extractionDebug:{platform,priceCandidates:priceCandidates.slice(0,25).map(x=>({value:x.value,score:x.score,evidence:x.evidence})),resourcePrice:resourcePrice?{value:resourcePrice.value,score:resourcePrice.score,evidence:resourcePrice.evidence}:null}
    };
  }

  CB.getStructured=structured;
  CB.detectPlatform=detectPlatform;
  CB.extractUniversal=extractUniversal;
  CB.lines=lines;
  CB.money=money;
})();
