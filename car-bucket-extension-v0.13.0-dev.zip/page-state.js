(() => {
  // Runs in the page's MAIN world so we can read application state that an
  // isolated extension content script cannot see. We only publish small,
  // JSON-serializable snapshots for vehicle extraction.
  const KEYS = [
    '__NEXT_DATA__','__NUXT__','__INITIAL_STATE__','__PRELOADED_STATE__',
    '__APOLLO_STATE__','__INITIAL_DATA__','__PAGE_DATA__','__DATA__',
    '__VEHICLE__','__INVENTORY__','__INVENTORY_DATA__'
  ];
  const MAX = 1500000;
  const safe = value => {
    try {
      const raw = JSON.stringify(value);
      if (!raw || raw.length > MAX) return '';
      return raw;
    } catch (_) { return ''; }
  };
  const publish = () => {
    const payload = {};
    for (const key of KEYS) {
      const raw = safe(window[key]);
      if (raw) payload[key] = raw;
    }
    // Also expose scripts that explicitly advertise JSON/application state.
    for (const node of document.querySelectorAll('script[type="application/json"],script[type="application/ld+json"]')) {
      const raw = node.textContent || '';
      if (raw && raw.length <= MAX) payload.__SCRIPT__ = (payload.__SCRIPT__ || '') + raw.slice(0, MAX);
    }
    window.postMessage({type:'CAR_BUCKET_PAGE_STATE', payload}, '*');
  };
  window.addEventListener('CAR_BUCKET_REQUEST_STATE', publish);
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', publish, {once:true});
  } else publish();
})();
