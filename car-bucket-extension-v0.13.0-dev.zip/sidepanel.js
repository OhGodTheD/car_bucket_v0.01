const $ = s => document.querySelector(s);
let listings = [], selected = new Set();
const money = n => n == null ? '—' : new Intl.NumberFormat('en-US',{style:'currency',currency:'USD',maximumFractionDigits:0}).format(n);
const filterIds=['year','make','model','minMiles','maxMiles','minPrice','maxPrice','watchFilter'];
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num = v => Number.isFinite(Number(v)) ? Number(v) : null;
const normalize = x => ({
  ...x,
  year:num(x.year), mileage:num(x.mileage), price:num(x.price),
  make:String(x.make||'').trim(), model:String(x.model||'').trim(), trim:String(x.trim||'').trim(),
  vin:String(x.vin||'').trim().toUpperCase(), stock:String(x.stock||'').trim(),
  priceHistory:Array.isArray(x.priceHistory)?x.priceHistory.filter(p=>p&&p.price!=null):[],
  watch:Boolean(x.watch), status:x.status||'Saved'
});
async function load(){
  const data=await chrome.storage.local.get({listings:[]}); listings=(data.listings||[]).map(normalize);
  const ui=await chrome.storage.local.get({filtersOpen:false,sort:'saved'});
  $('#sort').value=ui.sort||'saved'; setFiltersOpen(Boolean(ui.filtersOpen),false); render(); updateFilterCount();
}
async function persist(){await chrome.storage.local.set({listings});}
function normalizedTitle(x){return [x.year,x.make,x.model,x.trim].filter(Boolean).join(' ')||x.title||'Vehicle';}
function filtered(){
 const q=$('#search').value.toLowerCase().trim(), y=Number($('#year').value)||null, make=$('#make').value.toLowerCase().trim(), model=$('#model').value.toLowerCase().trim();
 const minMiles=Number($('#minMiles').value)||null,maxMiles=Number($('#maxMiles').value)||null,minPrice=Number($('#minPrice').value)||null,maxPrice=Number($('#maxPrice').value)||null,wf=$('#watchFilter').value;
 let a=listings.filter(x=>{const hay=`${normalizedTitle(x)} ${x.vin||''} ${x.stock||''} ${x.dealer||''} ${x.location||''} ${x.source||''}`.toLowerCase();return(!q||hay.includes(q))&&(!y||x.year===y)&&(!make||x.make.toLowerCase().includes(make))&&(!model||x.model.toLowerCase().includes(model))&&(!minMiles||(x.mileage!=null&&x.mileage>=minMiles))&&(!maxMiles||(x.mileage!=null&&x.mileage<=maxMiles))&&(!minPrice||(x.price!=null&&x.price>=minPrice))&&(!maxPrice||(x.price!=null&&x.price<=maxPrice))&&(wf==='all'||(wf==='watched'?x.watch:!x.watch));});
 const sort=$('#sort').value, dirs={priceAsc:['price',1],priceDesc:['price',-1],milesAsc:['mileage',1],milesDesc:['mileage',-1],yearDesc:['year',-1],yearAsc:['year',1]};
 if(dirs[sort]){const[k,d]=dirs[sort];a.sort((u,v)=>((u[k]??Infinity)-(v[k]??Infinity))*d);} else a.sort((u,v)=>new Date(v.savedAt||0)-new Date(u.savedAt||0)); return a;
}
function comparable(x){
 return listings.filter(v=>v.id!==x.id&&v.price!=null&&x.price!=null&&String(v.make).toLowerCase()===String(x.make).toLowerCase()&&String(v.model).toLowerCase()===String(x.model).toLowerCase()&&(!x.year||!v.year||Math.abs(v.year-x.year)<=1)&&(!x.mileage||!v.mileage||Math.abs(v.mileage-x.mileage)<=Math.max(15000,x.mileage*.25)));
}
function marketFor(x){
 const peers=comparable(x); if(x.price==null||peers.length<1)return null;
 const prices=[x,...peers].map(v=>v.price).filter(Number.isFinite).sort((a,b)=>a-b); const median=prices[Math.floor(prices.length/2)];
 return {count:prices.length,min:prices[0],max:prices.at(-1),median,delta:x.price-median,peers};
}
function historyText(x){
 const h=x.priceHistory||[]; if(h.length<2)return '';
 const first=h[0].price,last=h.at(-1).price; if(first===last)return '';
 return `${last<first?'↓':'↑'} ${money(Math.abs(last-first))} since saved`;
}
function intelText(x){
 const m=marketFor(x), parts=[]; const h=historyText(x); if(h)parts.push(h);
 if(m){const delta=Math.round(Math.abs(m.delta)); parts.push(`${m.count} similar · ${m.delta<0?'below':'above'} median by ${money(delta)}`);}
 if(x.lastCheckedAt)parts.push(`Checked ${new Date(x.lastCheckedAt).toLocaleDateString()}`); return parts.join('  •  ');
}
function render(){
 const a=filtered(); $('#count').textContent=`${listings.length} ${listings.length===1?'vehicle':'vehicles'}`; $('#resultCount').textContent=`${a.length} ${a.length===1?'result':'results'}`;
 const watched=listings.filter(x=>x.watch).length; $('#marketHint').textContent=watched?`${watched} watched`:''; const root=$('#list'); root.replaceChildren();
 if(!a.length){root.innerHTML='<div class="empty"><div class="emptyIcon"><img src="icon128.png" alt=""></div><b>No vehicles found</b><span>Save a listing or adjust your filters.</span></div>';updateCompareBar();return;}
 a.forEach(x=>{const c=$('#cardTemplate').content.cloneNode(true),card=c.querySelector('.card'),img=c.querySelector('.thumb');
   if(x.image){img.src=x.image;img.onerror=()=>{img.style.display='none';}}else img.style.display='none';
   const status=c.querySelector('.status'); status.textContent=x.watch?'Watching':(x.status||'Saved'); status.classList.toggle('watching',!!x.watch);
   c.querySelector('.title').textContent=normalizedTitle(x); c.querySelector('.meta').textContent=[x.dealer,x.source].filter(Boolean).join(' · ');
   c.querySelector('.price').textContent=money(x.price); c.querySelector('.miles').textContent=x.mileage!=null?`${x.mileage.toLocaleString()} mi`:'Mileage —';
   c.querySelector('.submeta').textContent=[x.vin&&`VIN ${x.vin}`,x.stock&&`Stock ${x.stock}`,x.location].filter(Boolean).join(' · ');
   c.querySelector('.intel').textContent=intelText(x); c.querySelector('.notes').textContent=x.notes||'';
   const m=marketFor(x); const market=c.querySelector('.market'); if(m){market.hidden=false;market.querySelector('.marketMain').textContent=`${m.count} comparable${m.count===1?'':'s'} in bucket`;market.querySelector('.marketRange').textContent=`${money(m.min)} – ${money(m.max)}`;market.querySelector('.marketMedian').textContent=`Median ${money(m.median)}`;market.classList.toggle('under',m.delta<0);market.classList.toggle('over',m.delta>0);market.querySelector('.marketDelta').textContent=`${m.delta<0?'Below':'Above'} median ${money(Math.abs(m.delta))}`;}
   const chk=c.querySelector('.select'); chk.checked=selected.has(x.id); chk.onchange=()=>{chk.checked?selected.add(x.id):selected.delete(x.id);updateCompareBar();};
   c.querySelector('.open').onclick=()=>chrome.tabs.create({url:x.url});
   c.querySelector('.delete').onclick=async()=>{selected.delete(x.id);listings=listings.filter(v=>v.id!==x.id);await persist();render();};
   c.querySelector('.edit').onclick=()=>edit(x);
   const wb=c.querySelector('.watch'); wb.textContent=x.watch?'Watching':'Watch'; wb.classList.toggle('watching',!!x.watch); wb.onclick=async()=>{x.watch=!x.watch;if(x.watch&&!x.lastCheckedAt)x.lastCheckedAt=new Date().toISOString();await persist();render();};
   root.append(card);
 }); updateCompareBar();
}
async function edit(x){const notes=prompt('Notes for this vehicle:',x.notes||'');if(notes===null)return;const status=prompt('Status (Saved, Contacted, Test Drive, Bought, Passed):',x.status||'Saved');if(status===null)return;x.notes=notes;x.status=status.trim()||'Saved';await persist();render();}
function notice(msg){const n=$('#notice');n.textContent=msg;n.hidden=false;clearTimeout(notice.t);notice.t=setTimeout(()=>n.hidden=true,3200);}
async function saveCurrent(){
 const [tab]=await chrome.tabs.query({active:true,currentWindow:true}); if(!tab?.id){notice('No active tab.');return;}
 try{const r=await chrome.tabs.sendMessage(tab.id,{type:'EXTRACT_LISTING'});if(!r?.ok)throw Error(r?.error||'Extraction failed');const x=normalize(r.listing);const existing=listings.find(v=>(x.vin&&v.vin===x.vin)||v.url===x.url);const now=new Date().toISOString();
   if(existing){const history=[...(existing.priceHistory||[])];if(x.price!=null&&(history.length===0||history.at(-1).price!==x.price))history.push({price:x.price,at:now});Object.assign(existing,x,{id:existing.id,savedAt:existing.savedAt,notes:existing.notes,status:existing.status,watch:existing.watch,priceHistory:history,lastCheckedAt:now});notice(x.price!=null?'Updated vehicle data.':'Updated vehicle; price not found.');}
   else {x.id=crypto.randomUUID();x.savedAt=now;x.status='Saved';x.watch=false;x.priceHistory=x.price!=null?[{price:x.price,at:now}]:[];x.lastCheckedAt=now;listings.unshift(x);notice(x.price!=null?'Saved to Car Bucket.':'Saved; price not found on page.');}
   await persist();render();
 }catch(e){console.error(e);notice('Could not read this listing.');}
}
function setFiltersOpen(open,persistState=true){$('#filters').hidden=!open;$('#filterToggle').setAttribute('aria-expanded',String(open));if(persistState)chrome.storage.local.set({filtersOpen:open});}
function updateFilterCount(){const n=filterIds.filter(id=>$('#'+id).value&&$('#'+id).value!=='all').length;$('#filterCount').textContent=n;$('#filterCount').hidden=!n;}
function updateCompareBar(){const n=selected.size;$('#compareBar').hidden=n===0;$('#compareCount').textContent=n;}
function compare(){const xs=listings.filter(x=>selected.has(x.id));if(xs.length<2){notice('Select at least two vehicles.');return;}$('#compareSubtitle').textContent=`${xs.length} vehicles`;const grid=$('#compareGrid');grid.replaceChildren();const fields=[['Price',x=>money(x.price)],['Mileage',x=>x.mileage!=null?`${x.mileage.toLocaleString()} mi`:'—'],['Year',x=>x.year||'—'],['Trim',x=>x.trim||'—'],['Dealer',x=>x.dealer||'—'],['Source',x=>x.source||'—'],['VIN',x=>x.vin||'—']];xs.forEach(x=>{const col=document.createElement('section');col.className='compareCol';col.innerHTML=`<img src="${esc(x.image||'icon128.png')}" alt=""><h3>${esc(normalizedTitle(x))}</h3>${fields.map(([k,f])=>`<div class="compareField"><span>${esc(k)}</span><b>${esc(f(x))}</b></div>`).join('')}<button class="open compareOpen">View listing</button>`;col.querySelector('.compareOpen').onclick=()=>chrome.tabs.create({url:x.url});grid.append(col);});$('#compareModal').hidden=false;}
$('#save').onclick=saveCurrent;$('#filterToggle').onclick=()=>setFiltersOpen($('#filters').hidden);$('#resetFilters').onclick=()=>{filterIds.forEach(id=>$('#'+id).value=id==='watchFilter'?'all':'');render();updateFilterCount();};$('#clearSearch').onclick=()=>{$('#search').value='';$('#clearSearch').hidden=true;render();};
filterIds.forEach(id=>$('#'+id).addEventListener('input',()=>{render();updateFilterCount();}));$('#sort').addEventListener('change',async()=>{await chrome.storage.local.set({sort:$('#sort').value});render();});$('#search').addEventListener('input',()=>{$('#clearSearch').hidden=!$('#search').value;render();});$('#compare').onclick=compare;$('#clearCompare').onclick=()=>{selected.clear();updateCompareBar();render();};$('#closeCompare').onclick=()=>$('#compareModal').hidden=true;$('#compareModal').addEventListener('click',e=>{if(e.target.id==='compareModal')$('#compareModal').hidden=true;});
load();
